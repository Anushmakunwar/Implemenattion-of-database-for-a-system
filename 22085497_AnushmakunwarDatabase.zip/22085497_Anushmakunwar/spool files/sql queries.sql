INFORMATION QUERY
1) SELECT *
FROM Customers
WHERE CustomerCategory = 'Staff';

2) SELECT *
FROM Orders
WHERE ProductsPurchased = 'Computer'
  AND OrderDate BETWEEN TO_DATE('2023-05-01', 'YYYY-MM-DD') AND TO_DATE('2023-05-28', 'YYYY-MM-DD');

3) SELECT Customers.CustomerID, CustomerName, ProductsPurchased, OrderDate
FROM Customers
LEFT JOIN Orders ON Customers.CustomerID = Orders.CustomerID;

4) SELECT *
FROM Product
WHERE SUBSTR(ProductName, 2, 1) = 'a' AND StockQuantity > 50;
5) SELECT *
FROM (
  SELECT Customers.CustomerID, CustomerName, MAX(OrderDate) AS LatestOrderDate
  FROM Customers
  JOIN Orders ON Customers.CustomerID = Orders.CustomerID
  GROUP BY Customers.CustomerID, CustomerName
  ORDER BY LatestOrderDate DESC
)
WHERE ROWNUM = 1;

TRANSACTION QUERY

1) SELECT TO_CHAR(OrderDate, 'YYYY-MM') AS Month, SUM(TotalOrderAmount) AS TotalRevenue
FROM Orders
GROUP BY TO_CHAR(OrderDate, 'YYYY-MM')
ORDER BY TO_CHAR(OrderDate, 'YYYY-MM');

2) SELECT *
FROM Orders
WHERE TotalOrderAmount >= (SELECT AVG(TotalOrderAmount) FROM Orders);
3) 
SELECT VendorID, VendorName, ProductSupplied FROM Vendor WHERE ProductSupplied > 3;

4)  SELECT *
   FROM (
      SELECT
          Product.ProductID,
           Product.ProductName,
          Product.Description,
          Product.Price,
          Product.StockLevel,
          Product.StockQuantity,
           SUM(Orders.Quantities) AS TotalOrderedQuantity,
           ROW_NUMBER() OVER (ORDER BY SUM(Orders.Quantities) DESC) AS rnum
       FROM
          Product
       JOIN
          OrderedProduct ON Product.ProductID = OrderedProduct.ProductID
      JOIN
          Orders ON OrderedProduct.OrderID = Orders.OrderID
      GROUP BY
          Product.ProductID,
         Product.ProductName,
         Product.Description,
        Product.Price,
        Product.StockLevel,
        Product.StockQuantity
  )
   WHERE rnum <= 3;


5) SELECT *
FROM (
  SELECT Customers.CustomerID, CustomerName, SUM(TotalOrderAmount) AS TotalSpending,
         DENSE_RANK() OVER (ORDER BY SUM(TotalOrderAmount) DESC) AS rnum
  FROM Customers
  JOIN Orders ON Customers.CustomerID = Orders.CustomerID
  WHERE TO_CHAR(OrderDate, 'YYYY-MM') = '2023-08'
  GROUP BY Customers.CustomerID, CustomerName
)
WHERE rnum = 1;


